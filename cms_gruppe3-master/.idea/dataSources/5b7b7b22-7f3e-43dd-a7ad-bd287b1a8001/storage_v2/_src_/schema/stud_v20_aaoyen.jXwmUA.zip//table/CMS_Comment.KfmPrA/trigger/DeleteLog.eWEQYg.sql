create definer = stud_v20_aaoyen@`%` trigger DeleteLog
    after delete
    on CMS_Comment
    for each row
    INSERT INTO CMS_Logs VALUES(null, old.FK_User, old.text, old.PK_Comment, "Deleted", NOW());

